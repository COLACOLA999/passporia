<template>
    <div ref="mapContainer" class="world-map"></div>
  </template>
  
  <script setup>
  import { ref, onMounted } from 'vue'
  import * as echarts from 'echarts'
  import worldJSON from '@/assets/maps/world.json' 
  
  const mapContainer = ref(null)
  
  echarts.registerMap('world', worldJSON)
  
  onMounted(() => {
    const chart = echarts.init(mapContainer.value)
    
    const option = {
      tooltip: {
        trigger: 'item',
        formatter: '{b}'
      },
      geo: {
        map: 'world',
        roam: true, 
        label: {
          show: true, 
          fontSize: 10
        },
        itemStyle: {
          areaColor: '#E6F7FF', 
          borderColor: '#1890FF' 
        },
        emphasis: {
          itemStyle: {
            areaColor: '#91D5FF' 
          }
        }
      }
    }
  
    chart.setOption(option)
  })
  </script>
  
  <style scoped>
  .world-map {
    width: 100%;
    height: 600px;
    border-radius: 8px;
    box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1);
  }
  </style>